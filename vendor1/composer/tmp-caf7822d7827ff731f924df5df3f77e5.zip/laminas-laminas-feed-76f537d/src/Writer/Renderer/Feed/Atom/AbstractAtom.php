<?php

declare(strict_types=1);

namespace Laminas\Feed\Writer\Renderer\Feed\Atom;

use DateTime;
use DOMDocument;
use DOMElement;
use Laminas\Feed;
use Laminas\Feed\Writer\Version;

use function array_key_exists;
use function strtolower;

class AbstractAtom extends Feed\Writer\Renderer\AbstractRenderer
{
    /**
     * @param Feed\Writer\Feed $container
     */
    public function __construct($container)
    {
        parent::__construct($container);
    }

    // phpcs:disable PSR2.Methods.MethodDeclaration.Underscore

    /**
     * Set feed language
     *
     * @return void
     */
    protected function _setLanguage(DOMDocument $dom, DOMElement $root)
    {
        if ($this->getDataContainer()->getLanguage()) {
            $root->setAttribute('xml:lang', $this->getDataContainer()->getLanguage());
        }
    }

    /**
     * Set feed title
     *
     * @return void
     * @throws Feed\Exception\InvalidArgumentException
     */
    protected function _setTitle(DOMDocument $dom, DOMElement $root)
    {
        if (! $this->getDataContainer()->getTitle()) {
            $message   = 'Atom 1.0 feed elements MUST contain exactly one'
                . ' atom:title element but a title has not been set';
            $exception = new Feed\Exception\InvalidArgumentException($message);
            if (! $this->ignoreExceptions) {
                throw $exception;
            } else {
                $this->exceptions[] = $exception;
                return;
            }
        }

        $title = $dom->createElement('title');
        $root->appendChild($title);
        $title->setAttribute('type', 'text');
        $text = $dom->createTextNode((string) $this->getDataContainer()->getTitle());
        $title->appendChild($text);
    }

    /**
     * Set feed description
     *
     * @return void
     */
    protected function _setDescription(DOMDocument $dom, DOMElement $root)
    {
        if (! $this->getDataContainer()->getDescription()) {
            return;
        }
        $subtitle = $dom->createElement('subtitle');
        $root->appendChild($subtitle);
        $subtitle->setAttribute('type', 'text');
        $text = $dom->createTextNode((string) $this->getDataContainer()->getDescription());
        $subtitle->appendChild($text);
    }

    /**
     * Set date feed was last modified
     *
     * @return void
     * @throws Feed\Exception\InvalidArgumentException
     */
    protected function _setDateModified(DOMDocument $dom, DOMElement $root)
    {
        if (! $this->getDataContainer()->getDateModified()) {
            $message   = 'Atom 1.0 feed elements MUST contain exactly one'
                . ' atom:updated element but a modification date has not been set';
            $exception = new Feed\Exception\InvalidArgumentException($message);
            if (! $this->ignoreExceptions) {
                throw $exception;
            } else {
                $this->exceptions[] = $exception;
                return;
            }
        }

        $updated = $dom->createElement('updated');
        $root->appendChild($updated);
        $text = $dom->createTextNode(
            $this->getDataContainer()->getDateModified()->format(DateTime::ATOM)
        );
        $updated->appendChild($text);
    }

    /**
     * Set feed generator string
     *
     * @return void
     */
    protected function _setGenerator(DOMDocument $dom, DOMElement $root)
    {
        if (! $this->getDataContainer()->getGenerator()) {
            $this->getDataContainer()->setGenerator(
                'Laminas_Feed_Writer',
                Version::VERSION,
                'https://getlaminas.org'
            );
        }

        $gdata     = $this->getDataContainer()->getGenerator();
        $generator = $dom->createElement('generator');
        $root->appendChild($generator);
        $text = $dom->createTextNode((string) $gdata['name']);
        $generator->appendChild($text);
        if (array_key_exists('uri', $gdata)) {
            $generator->setAttribute('uri', $gdata['uri']);
        }
        if (array_key_exists('version', $gdata)) {
            $generator->setAttribute('version', $gdata['version']);
        }
    }

    /**
     * Set link to feed
     *
     * @return void
     */
    protected function _setLink(DOMDocument $dom, DOMElement $root)
    {
        if (! $this->getDataContainer()->getLink()) {
            return;
        }
        $link = $dom->createElement('link');
        $root->appendChild($link);
        $link->setAttribute('rel', 'alternate');
        $link->setAttribute('type', 'text/html');
        $link->setAttribute('href', $this->getDataContainer()->getLink());
    }

    /**
     * Set feed links
     *
     * @return void
     * @throws Feed\Exception\InvalidArgumentException
     */
    protected function _setFeedLinks(DOMDocument $dom, DOMElement $root)
    {
        $flinks = $this->getDataContainer()->getFeedLinks();
        if (! $flinks || ! array_key_exists('atom', $flinks)) {
            $message   = 'Atom 1.0 feed elements SHOULD contain one atom:link '
                . 'element with a rel attribute value of "self".  This is the '
                . 'preferred URI for retrieving Atom Feed Documents representing '
                . 'this Atom feed but a feed link has not been set';
            $exception = new Feed\Exception\InvalidArgumentException($message);
            if (! $this->ignoreExceptions) {
                throw $exception;
            } else {
                $this->exceptions[] = $exception;
                return;
            }
        }

        foreach ($flinks as $type => $href) {
            $mime  = 'application/' . strtolower($type) . '+xml';
            $flink = $dom->createElement('link');
            $root->appendChild($flink);
            $flink->setAttribute('rel', 'self');
            $flink->setAttribute('type', $mime);
            $flink->setAttribute('href', $href);
        }
    }

    /**
     * Set feed authors
     *
     * @return void
     */
    protected function _setAuthors(DOMDocument $dom, DOMElement $root)
    {
        $authors = $this->container->getAuthors();
        if (! $authors || empty($authors)) {
            /**
             * Technically we should defer an exception until we can check
             * that all entries contain an author. If any entry is missing
             * an author, then a missing feed author element is invalid
             */
            return;
        }
        foreach ($authors as $data) {
            $author = $this->dom->createElement('author');
            $name   = $this->dom->createElement('name');
            $author->appendChild($name);
            $root->appendChild($author);
            $text = $dom->createTextNode((string) $data['name']);
            $name->appendChild($text);
            if (array_key_exists('email', $data)) {
                $email = $this->dom->createElement('email');
                $author->appendChild($email);
                $text = $dom->createTextNode((string) $data['email']);
                $email->appendChild($text);
            }
            if (array_key_exists('uri', $data)) {
                $uri = $this->dom->createElement('uri');
                $author->appendChild($uri);
                $text = $dom->createTextNode((string) $data['uri']);
                $uri->appendChild($text);
            }
        }
    }

    /**
     * Set feed identifier
     *
     * @return void
     * @throws Feed\Exception\InvalidArgumentException
     */
    protected function _setId(DOMDocument $dom, DOMElement $root)
    {
        if (
            ! $this->getDataContainer()->getId()
            && ! $this->getDataContainer()->getLink()
        ) {
            $message   = 'Atom 1.0 feed elements MUST contain exactly one '
                . 'atom:id element, or as an alternative, we can use the same '
                . 'value as atom:link however neither a suitable link nor an '
                . 'id have been set';
            $exception = new Feed\Exception\InvalidArgumentException($message);
            if (! $this->ignoreExceptions) {
                throw $exception;
            } else {
                $this->exceptions[] = $exception;
                return;
            }
        }

        if (! $this->getDataContainer()->getId()) {
            $this->getDataContainer()->setId(
                $this->getDataContainer()->getLink()
            );
        }
        $id = $dom->createElement('id');
        $root->appendChild($id);
        $text = $dom->createTextNode((string) $this->getDataContainer()->getId());
        $id->appendChild($text);
    }

    /**
     * Set feed copyright
     *
     * @return void
     */
    protected function _setCopyright(DOMDocument $dom, DOMElement $root)
    {
        $copyright = $this->getDataContainer()->getCopyright();
        if (! $copyright) {
            return;
        }
        $copy = $dom->createElement('rights');
        $root->appendChild($copy);
        $text = $dom->createTextNode($copyright);
        $copy->appendChild($text);
    }

    /**
     * Set feed level logo (image)
     *
     * @return void
     */
    protected function _setImage(DOMDocument $dom, DOMElement $root)
    {
        $image = $this->getDataContainer()->getImage();
        if (! $image) {
            return;
        }
        $img = $dom->createElement('logo');
        $root->appendChild($img);
        $text = $dom->createTextNode((string) $image['uri']);
        $img->appendChild($text);
    }

    /**
     * Set date feed was created
     *
     * @return void
     */
    protected function _setDateCreated(DOMDocument $dom, DOMElement $root)
    {
        if (! $this->getDataContainer()->getDateCreated()) {
            return;
        }
        if (! $this->getDataContainer()->getDateModified()) {
            $this->getDataContainer()->setDateModified(
                $this->getDataContainer()->getDateCreated()
            );
        }
    }

    /**
     * Set base URL to feed links
     *
     * @return void
     */
    protected function _setBaseUrl(DOMDocument $dom, DOMElement $root)
    {
        $baseUrl = $this->getDataContainer()->getBaseUrl();
        if (! $baseUrl) {
            return;
        }
        $root->setAttribute('xml:base', $baseUrl);
    }

    /**
     * Set hubs to which this feed pushes
     *
     * @return void
     */
    protected function _setHubs(DOMDocument $dom, DOMElement $root)
    {
        $hubs = $this->getDataContainer()->getHubs();
        if (! $hubs) {
            return;
        }
        foreach ($hubs as $hubUrl) {
            $hub = $dom->createElement('link');
            $hub->setAttribute('rel', 'hub');
            $hub->setAttribute('href', $hubUrl);
            $root->appendChild($hub);
        }
    }

    /**
     * Set feed categories
     *
     * @return void
     */
    protected function _setCategories(DOMDocument $dom, DOMElement $root)
    {
        $categories = $this->getDataContainer()->getCategories();
        if (! $categories) {
            return;
        }
        foreach ($categories as $cat) {
            $category = $dom->createElement('category');
            $category->setAttribute('term', $cat['term']);
            if (isset($cat['label'])) {
                $category->setAttribute('label', $cat['label']);
            } else {
                $category->setAttribute('label', $cat['term']);
            }
            if (isset($cat['scheme'])) {
                $category->setAttribute('scheme', $cat['scheme']);
            }
            $root->appendChild($category);
        }
    }

    // phpcs:enable PSR2.Methods.MethodDeclaration.Underscore
}
