<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Magento\Framework\App\Action;

/**
 * Marker for actions processing GET requests.
 *
 * @api
 */
interface HttpGetActionInterface extends HttpHeadActionInterface
{

}
