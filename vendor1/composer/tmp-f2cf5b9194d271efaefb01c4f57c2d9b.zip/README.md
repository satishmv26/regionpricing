# InventoryIndexer module

The `InventoryIndexer` module provides indexation logic for Inventory Management.

This module is part of the new inventory infrastructure. The
[Inventory Management overview](https://developer.adobe.com/commerce/webapi/rest/inventory/index.html)
describes the MSI (Multi-Source Inventory) project in more detail.

## Installation details

This module is installed as part of Magento Open Source. It cannot be deleted or disabled.

## Extension points and service contracts

There are no extension points or service contracts for this module.
