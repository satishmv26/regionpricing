<?php

namespace Laminas\Text\Table\Decorator;

use Laminas\Text\Table\Decorator\DecoratorInterface as Decorator;

/**
 * ASCII Decorator for Laminas\Text\Table
 */
class Blank implements Decorator
{
    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getTopLeft()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getTopRight()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getBottomLeft()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getBottomRight()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getVertical()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getHorizontal()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getCross()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getVerticalRight()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getVerticalLeft()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getHorizontalDown()
    {
        return '';
    }

    /**
     * Defined by Laminas\Text\Table\Decorator\DecoratorInterface
     *
     * @return string
     */
    public function getHorizontalUp()
    {
        return '';
    }
}
